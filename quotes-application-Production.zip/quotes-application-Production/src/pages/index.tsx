"use client";
import Head from "next/head";
import Banner from "@/components/HomePage/Banner";
import { fetchDataFromDatabase, getTotalItemsFromDatabase } from "@/lib/db";
import {
  GetServerSideProps,
  GetServerSidePropsContext,
  GetServerSidePropsResult,
} from "next";

interface DataItem {
  id: number;
  title: string;
  image: string;
  create_at: string;
}

interface HomeProps {
  data: DataItem[];
  page: string | string[]; // Keep as string
  itemsPerPage: number;
  currentPage?: number; // Optional
  totalPages?: number; // Optional
}

export const getServerSideProps: GetServerSideProps<HomeProps> = async (
  context: GetServerSidePropsContext
): Promise<{ props: HomeProps }> => {
  const { page = "1", where = "" } = context.query; // Get the current page and where condition from the query parameters
  const table = "quote";

  try {
    const itemsPerPage = 8;
    const currentPage = Number(page); // Cast page to a number

    const data = await fetchDataFromDatabase(
      table,
      where,
      currentPage,
      itemsPerPage
    ); // Pass where condition

    // Calculate the total number of items in your database
    const totalItems = await getTotalItemsFromDatabase(table, where); // Pass where condition

    // Calculate the total number of pages
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    // Example: Transform your data (format, filter, or process it as needed)
    const formattedData: DataItem[] = data.map((item) => ({
      id: item.id,
      title: item.title,
      image: item.image,
      create_at: new Date(item.create_at).toISOString(),
    }));

    return {
      props: {
        currentPage,
        totalPages,
        data: formattedData,
        page, // Include page in props
        itemsPerPage, // Include itemsPerPage in props
      },
    };
  } catch (error) {
    console.error("Error fetching data:", error);
    return {
      props: {
        itemsPerPage: 3,
        currentPage: 1,
        totalPages: 1,
        data: [],
        page: "1",
      }, // Add a default value for page as a string
    };
  }
};

export default function Home({
  itemsPerPage,
  currentPage,
  page,
  totalPages,
  data,
}: HomeProps) {
  return (
    <>
      <Head>
        <title>
          Discover the Power of Quotes with Dream Bigly Motivational Quotes
        </title>
        <meta
          name="description"
          content="Unlock your dreams with inspirational hindi quotes, funny, birthday, morning, wishes, and heartfelt sadness quotes. Dive into our inspiring image quote collection today with dream bigly."
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="canonical" href="https://dreambigly.in" />
        <meta name="author" content="Dream Bigly" />
        <meta name="p:domain_verify" content="93ba5b721ffe693beea40a7474754c1b"/>
        <meta
          name="keywords"
          content="dream bigly quotes, success quotes, positive attitude quotes, hindi motivational quotes, urdu motivational quotes, morning quotes, love quotes, funny quotes, birthday quotes, good night quotes, sad quotes"
        />
        <meta
          name="robots"
          content="index, follow, max-image-preview:large, max-snippet:-1"
        />
      </Head>
      <Banner
        data={data}
        itemsPerPage={itemsPerPage}
        page={page}
        currentPage={currentPage}
        totalPages={totalPages}
      />
    </>
  );
}
