import Head from "next/head";
import styles from "@/styles/Home.module.scss";
import AbousUs from "@/components/Pages/AbousUs";

const AboutUs: React.FC = () => {
  return (
    <>
      <Head>
        <title>About Us - Discover Our Story and Mission | Dream Bigly</title>
        <meta
          name="description"
          content="Learn about Dream Bigly - Your source of inspiration and motivation. Discover our story and mission. Join us on the journey to dream big and achieve greatness."
        />
        <link rel="canonical" href="https://dreambigly.in/about-us" />
        <meta
          name="robots"
          content="index, follow, max-image-preview:large, max-snippet:-1"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <meta
          name="robots"
          content="index, follow, max-image-preview:large, max-snippet:-1"
        />
      </Head>
      <main>
        <AbousUs />
      </main>
    </>
  );
};

export default AboutUs;
