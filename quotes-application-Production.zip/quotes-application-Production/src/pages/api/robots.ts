// pages/api/robots.ts
import { MetadataRoute } from 'next';
import { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  // const userAgent = req.headers?.['user-agent']!;
  // const isBot = /bot|googlebot|crawler|spider|robot/i.test(userAgent);

  // if (isBot) {
  //   // If the request is from a bot, send the dynamic robots.txt content
  //   const robotsData: MetadataRoute.Robots = {
  //     rules: [
  //       {
  //         userAgent: '*',
  //         allow: '/',
  //         disallow: '/riz-auth',
  //       },
  //     ],
  //     sitemap: [
  //       'http://localhost:3000/sitemap.xml', // Update this URL for production
  //       'https://dreambigly.in/sitemap.xml',
  //     ],
  //   };

  //   res.setHeader('Content-Type', 'text/plain;charset=UTF-8');
  //   res.status(200).send(robotsData);
  // } else {
  //   // If the request is not from a bot, respond with a simple message
  //   res.status(200).send('User-agent: *\nDisallow: /');
  // }/
  const content = `
    User-agent: *
    Disallow: /riz-auth

    sitemap: https://dreambigly.in/sitemap.xml
  `;

  res.setHeader('Content-Type', 'text/plain');
  res.status(200).send(content);
}





// // api/robots.ts



// export default (req: NextApiRequest, res: NextApiResponse) => {
//   const { query } = req;
  
//   // Customize the robots.txt content based on the page or route
//   const robotsTxt = `
//     User-agent: *
//     Disallow: ${query.page === 'private' ? '/riz-auth' : ''}
//   `;

//   res.setHeader('Content-Type', 'text/plain');
//   res.status(200).send(robotsTxt);
// };
