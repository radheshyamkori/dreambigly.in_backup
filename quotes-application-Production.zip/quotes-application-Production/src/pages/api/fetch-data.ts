// pages/api/fetch-data.ts
import { NextApiRequest, NextApiResponse } from 'next';
import { connectDatabase } from '../../lib/db';


export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method === 'POST') {
        try {
            const quotesInfo = req.body;
            // Create a connection to the MySQL database
            const db = await connectDatabase();

            // console.log(quotesInfo, "quotesInfo")
            // Insert the new quote into the database
            await db.query(
                'INSERT INTO quote (title, image, category ) VALUES (?, ?, ?)',
                [quotesInfo.quotesMessage, quotesInfo.image, quotesInfo.category]
            );

            // Close the database connection
            db.end();

            res.status(200).json({ message: 'Quote added successfully' });
        } catch (error) {
            console.log(error)
            console.error('Error adding quote to the database:', error);
            res.status(500).json({ error: 'Failed to add the quote' });
        }
    } else {
        res.status(405).json({ error: 'Method not allowed' });
    }
}
