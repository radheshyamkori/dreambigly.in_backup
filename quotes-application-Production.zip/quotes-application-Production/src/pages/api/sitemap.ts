// pages/api/sitemap.ts

import { NextApiRequest, NextApiResponse } from 'next';

const generateUrlXml = (url: any, lastModified: any, changeFrequency: any, priority: any) => `
  <url>
    <loc>${url}</loc>
    <lastmod>${lastModified.toISOString()}</lastmod>
    <changefreq>${changeFrequency}</changefreq>
    <priority>${priority}</priority>
  </url>`;

export default (req: NextApiRequest, res: NextApiResponse) => {
    // Generate your sitemap.xml content here

    const urls = [
        {
            url: 'https://dreambigly.in/',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 1,
        },
        {
            url: 'https://dreambigly.in/positive-attitude-quotes',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/morning-quotes',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/love-quotes',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/birthday-quotes',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/good-night-quotes',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/sad-quotes',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/funny-quotes',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/hindi-motivational-quotes',
            lastModified: new Date(),
            changeFrequency: 'daily',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/urdu-motivational-quotes',
            lastModified: new Date(),
            changeFrequency: 'monthly',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/success-quotes',
            lastModified: new Date(),
            changeFrequency: 'monthly',
            priority: 0.9,
        },
        {
            url: 'https://dreambigly.in/about-us',
            lastModified: new Date(),
            changeFrequency: 'monthly',
            priority: 0.8,
        },
    ]
    const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      ${urls.map(({ url, lastModified, changeFrequency, priority }) =>
        generateUrlXml(url, lastModified, changeFrequency, priority)
    ).join('')}
    </urlset>`;

    res.setHeader('Content-Type', 'text/xml');
    res.status(200).send(sitemapXml);
};
