// pages/api/download.ts

import { NextApiRequest, NextApiResponse } from 'next';

export default async (req: NextApiRequest, res: NextApiResponse) => {
  const { image } = req.query;

  try {
    const response = await fetch(image as string);

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const buffer = await response.arrayBuffer();
    const contentType = response.headers.get('content-type') || 'application/octet-stream';

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', 'attachment; filename=image.jpg');
    res.end(Buffer.from(buffer));
  } catch (error) {
    console.error('Error downloading image:', error);
    res.status(500).end('Internal Server Error');
  }
};
