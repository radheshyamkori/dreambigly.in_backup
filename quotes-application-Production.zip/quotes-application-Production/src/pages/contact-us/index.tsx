import Head from "next/head";
import styles from "@/styles/Home.module.scss";
import Link from "next/link";

const ContactUs: React.FC = () => {
  return (
    <>
      <Head>
        <title>Contact Us Today | Get in Touch with Dream Bigly</title>
        <meta
          name="description"
          content="Reach out to Dream Bigly and let us help you turn your dreams into reality. Contact us today for inquiries, support, or partnership opportunities. Your dreams deserve our attention!"
        />
        <meta name="robots" content="noindex, follow" />
        <link rel="canonical" href="https://dreambigly.in/contact-us" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <div className="conatiner mx-auto px-4 lg:max-w-7xl md:px-8">
        <div className="flex relative h-screen flex-col items-center px-4">
          <nav className="flex absolute top-4 left-0" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1 md:space-x-3">
              <li className="inline-flex items-center">
                <Link
                  href="https://dreambigly.in/"
                  className="inline-flex items-center text-sm font-medium text-slate-700 hover:text-[#296f77]"
                >
                  <svg
                    className="w-3 h-3 mr-2.5"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                  </svg>
                  Home
                </Link>
              </li>
              <li aria-current="page">
                <div className="flex items-center">
                  <svg
                    className="w-3 h-3 text-gray-400 mx-1"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 6 10"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m1 9 4-4-4-4"
                    />
                  </svg>
                  <span className="ml-1 text-sm font-medium text-gray-500 md:ml-2 dark:text-gray-400">
                    Funny Quotes
                  </span>
                </div>
              </li>
            </ol>
          </nav>
          <h1 className="text-xl md:text-xl lg:text-2xl text-gray-800 mt-12">
            Contact Us for Dream Bigly
          </h1>
          <Link
            href="mailto:rizwan@gmail.com"
            className="md:text-lg lg:text-xl text-gray-600 mt-8"
          >
            dreambigly.in@gmail.com
          </Link>
          <p className="md:text-lg lg:text-sm mt-3 text-center text-gray-600">
            {" "}
            @ Wireframe Design and Color Harmony of the website is strictly
            copyrighted to dreambigly.com
          </p>
        </div>
      </div>
    </>
  );
};

export default ContactUs;
