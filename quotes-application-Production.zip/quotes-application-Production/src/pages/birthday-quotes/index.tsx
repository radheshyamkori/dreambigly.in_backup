import Head from "next/head";
import styles from "@/styles/Home.module.scss";
import BirthdayQuote from "@/components/QuotesPages/BirthdayQuote";
import { fetchDataFromDatabase, getTotalItemsFromDatabase } from "@/lib/db";
import { GetServerSideProps, GetServerSidePropsContext } from "next";

interface DataItem {
  id: number;
  title: string;
  image: string;
  create_at: string;
}

interface BirthdayQuotesProps {
  data: DataItem[];
  page: string | string[]; // Keep as string
  itemsPerPage: number;
  currentPage?: number; // Optional
  totalPages?: number; // Optional
}

export const getServerSideProps: GetServerSideProps<
  BirthdayQuotesProps
> = async (
  context: GetServerSidePropsContext
): Promise<{ props: BirthdayQuotesProps }> => {
  const { page = "1", where = `${`category`} = "Birthday Quotes"` } =
    context.query; // Get the current page and where condition from the query parameters
  const table = "quote";

  try {
    const itemsPerPage = 32;
    const currentPage = Number(page); // Cast page to a number

    const data = await fetchDataFromDatabase(
      table,
      where,
      currentPage,
      itemsPerPage
    ); // Pass where condition

    // Calculate the total number of items in your database
    const totalItems = await getTotalItemsFromDatabase(table, where); // Pass where condition

    // Calculate the total number of pages
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    // Example: Transform your data (format, filter, or process it as needed)
    const formattedData: DataItem[] = data.map((item) => ({
      id: item.id,
      title: item.title,
      image: item.image,
      create_at: new Date(item.create_at).toISOString(),
    }));

    return {
      props: {
        currentPage,
        totalPages,
        data: formattedData,
        page, // Include page in props
        itemsPerPage, // Include itemsPerPage in props
      },
    };
  } catch (error) {
    console.error("Error fetching data:", error);
    return {
      props: {
        itemsPerPage: 32,
        currentPage: 1,
        totalPages: 1,
        data: [],
        page: "1",
      }, // Add a default value for page as a string
    };
  }
};

function BirthdayQuotes({
  itemsPerPage,
  currentPage,
  page,
  totalPages,
  data,
}: BirthdayQuotesProps) {
  return (
    <>
      <Head>
        <title>
          Celebrate with Heartfelt Wishes: Birthday Quotes - Dream Bigly
        </title>
        <meta
          name="description"
          content="Make birthdays special with Birthday Quotes. Find heartfelt and celebratory quotes to add joy and warmth to your wishes. Let Dream Bigly help you express love and warm wishes with words."
        />
        <link
          rel="canonical"
          href="https://dreambigly.in/birthday-quotes"
        />
        <meta
          name="keywords"
          content="birthday quotes, birthday wishes, happy birthday wishes, birthday wishes for friend, birthday wishes for sister, birthday wishes for husband"
        />
        <meta
          name="robots"
          content="index, follow, max-image-preview:large, max-snippet:-1"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <BirthdayQuote
        data={data}
        itemsPerPage={itemsPerPage}
        page={page}
        currentPage={currentPage}
        totalPages={totalPages}
      />
    </>
  );
}

export default BirthdayQuotes;
