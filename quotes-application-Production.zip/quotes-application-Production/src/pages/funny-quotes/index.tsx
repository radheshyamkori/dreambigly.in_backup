import Head from "next/head";
import styles from "@/styles/Home.module.scss";
import { fetchDataFromDatabase, getTotalItemsFromDatabase } from "@/lib/db";
import { GetServerSideProps, GetServerSidePropsContext } from "next";
import BeautyQuote from "@/components/QuotesPages/BeautyQuote";

interface DataItem {
  id: number;
  title: string;
  image: string;
  create_at: string;
}

interface BeautyQuotesProps {
  data: DataItem[];
  page: string | string[]; // Keep as string
  itemsPerPage: number;
  currentPage?: number; // Optional
  totalPages?: number; // Optional
}

export const getServerSideProps: GetServerSideProps<BeautyQuotesProps> = async (
  context: GetServerSidePropsContext
): Promise<{ props: BeautyQuotesProps }> => {
  const { page = "1", where = `${`category`} = "Funny Quotes"` } =
    context.query; // Get the current page and where condition from the query parameters
  const table = "quote";

  try {
    const itemsPerPage = 32;
    const currentPage = Number(page); // Cast page to a number

    const data = await fetchDataFromDatabase(
      table,
      where,
      currentPage,
      itemsPerPage
    ); // Pass where condition

    // Calculate the total number of items in your database
    const totalItems = await getTotalItemsFromDatabase(table, where); // Pass where condition

    // Calculate the total number of pages
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    // Example: Transform your data (format, filter, or process it as needed)
    const formattedData: DataItem[] = data.map((item) => ({
      id: item.id,
      title: item.title,
      image: item.image,
      create_at: new Date(item.create_at).toISOString(),
    }));

    return {
      props: {
        currentPage,
        totalPages,
        data: formattedData,
        page, // Include page in props
        itemsPerPage, // Include itemsPerPage in props
      },
    };
  } catch (error) {
    console.error("Error fetching data:", error);
    return {
      props: {
        itemsPerPage: 32,
        currentPage: 1,
        totalPages: 1,
        data: [],
        page: "1",
      }, // Add a default value for page as a string
    };
  }
};

function BeautyQuotes({
  itemsPerPage,
  currentPage,
  page,
  totalPages,
  data,
}: BeautyQuotesProps) {
  return (
    <>
      <Head>
        <title>Laughter Guaranteed: Funny Quotes | Dream Bigly</title>
        <meta
          name="description"
          content="Get a laugh with Funny Quotes. Explore humorous and witty quotes for a dose of humour and entertainment. Dream Bigly is your source of endless smiles and laughter."
        />
        <link rel="canonical" href="https://dreambigly.in/funny-quotes" />
        <meta
          name="keywords"
          content="funny quotes, funny quotes about life, funny friendship quotes, funniest captions, funny status, hilarious life quotes"
        />
        <meta
          name="robots"
          content="index, follow, max-image-preview:large, max-snippet:-1"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <BeautyQuote
        data={data}
        itemsPerPage={itemsPerPage}
        page={page}
        currentPage={currentPage}
        totalPages={totalPages}
      />
    </>
  );
}

export default BeautyQuotes;
