import Head from "next/head";
import styles from "@/styles/Home.module.scss";
import HindiMotivationalQuote from "@/components/QuotesPages/HindiMotivationalQuote";
import { GetServerSideProps, GetServerSidePropsContext } from "next";
import { fetchDataFromDatabase, getTotalItemsFromDatabase } from "@/lib/db";

interface DataItem {
  id: number;
  title: string;
  image: string;
  create_at: string;
}

interface HindiMotivationalProps {
  data: DataItem[];
  page: string | string[]; // Keep as string
  itemsPerPage: number;
  currentPage?: number; // Optional
  totalPages?: number; // Optional
}

export const getServerSideProps: GetServerSideProps<
  HindiMotivationalProps
> = async (
  context: GetServerSidePropsContext
): Promise<{ props: HindiMotivationalProps }> => {
  const { page = "1", where = `${`category`} = "Hindi Motivational Quotes"` } =
    context.query; // Get the current page and where condition from the query parameters
  const table = "quote";

  try {
    const itemsPerPage = 32;
    const currentPage = Number(page); // Cast page to a number

    const data = await fetchDataFromDatabase(
      table,
      where,
      currentPage,
      itemsPerPage
    ); // Pass where condition

    // Calculate the total number of items in your database
    const totalItems = await getTotalItemsFromDatabase(table, where); // Pass where condition

    // Calculate the total number of pages
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    // Example: Transform your data (format, filter, or process it as needed)
    const formattedData: DataItem[] = data.map((item) => ({
      id: item.id,
      title: item.title,
      image: item.image,
      create_at: new Date(item.create_at).toISOString(),
    }));

    return {
      props: {
        currentPage,
        totalPages,
        data: formattedData,
        page, // Include page in props
        itemsPerPage, // Include itemsPerPage in props
      },
    };
  } catch (error) {
    console.error("Error fetching data:", error);
    return {
      props: {
        itemsPerPage: 32,
        currentPage: 1,
        totalPages: 1,
        data: [],
        page: "1",
      }, // Add a default value for page as a string
    };
  }
};

function HindiMotivationalQuotes({
  itemsPerPage,
  currentPage,
  page,
  totalPages,
  data,
}: HindiMotivationalProps) {
  return (
    <>
      <Head>
        <title>
          Empowering Your Spirit: Hindi Motivational Quotes | Dream Bigly
        </title>
        <meta
          name="description"
          content="Explore Dream Bigly for uplifting Hindi Motivational Quotes. Ignite your inner drive with inspirational wisdom in Hindi. Fuel your success journey now."
        />
        <link
          rel="canonical"
          href="https://dreambigly.in/hindi-motivational-quotes"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="keywords" content="hindi motivational quotes, motivational quotes in hindi for success, motivational thoughts in hindi, best motivational quotes in hindi, motivational quotes in hindi for students, motivational quotes in hindi language" />
        <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <HindiMotivationalQuote
        data={data}
        itemsPerPage={itemsPerPage}
        page={page}
        currentPage={currentPage}
        totalPages={totalPages}
      />
    </>
  );
}
export default HindiMotivationalQuotes;
