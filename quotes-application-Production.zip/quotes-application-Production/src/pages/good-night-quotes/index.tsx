import Head from "next/head";
import styles from "@/styles/Home.module.scss";
import GoodNightQuote from "@/components/QuotesPages/GoodNightQuote";
import { GetServerSideProps, GetServerSidePropsContext } from "next";
import { fetchDataFromDatabase, getTotalItemsFromDatabase } from "@/lib/db";

interface DataItem {
  id: number;
  title: string;
  image: string;
  create_at: string;
}

interface GoodNightProps {
  data: DataItem[];
  page: string | string[]; // Keep as string
  itemsPerPage: number;
  currentPage?: number; // Optional
  totalPages?: number; // Optional
}

export const getServerSideProps: GetServerSideProps<GoodNightProps> = async (
  context: GetServerSidePropsContext
): Promise<{ props: GoodNightProps }> => {
  const { page = "1", where = `${`category`} = "Good Night Quotes"` } =
    context.query; // Get the current page and where condition from the query parameters
  const table = "quote";

  try {
    const itemsPerPage = 32;
    const currentPage = Number(page); // Cast page to a number

    const data = await fetchDataFromDatabase(
      table,
      where,
      currentPage,
      itemsPerPage
    ); // Pass where condition

    // Calculate the total number of items in your database
    const totalItems = await getTotalItemsFromDatabase(table, where); // Pass where condition

    // Calculate the total number of pages
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    // Example: Transform your data (format, filter, or process it as needed)
    const formattedData: DataItem[] = data.map((item) => ({
      id: item.id,
      title: item.title,
      image: item.image,
      create_at: new Date(item.create_at).toISOString(),
    }));

    return {
      props: {
        currentPage,
        totalPages,
        data: formattedData,
        page, // Include page in props
        itemsPerPage, // Include itemsPerPage in props
      },
    };
  } catch (error) {
    console.error("Error fetching data:", error);
    return {
      props: {
        itemsPerPage: 32,
        currentPage: 1,
        totalPages: 1,
        data: [],
        page: "1",
      }, // Add a default value for page as a string
    };
  }
};

function GoodNightQuotes({
  itemsPerPage,
  currentPage,
  page,
  totalPages,
  data,
}: GoodNightProps) {
  return (
    <>
      <Head>
        <title>Soothing Dreams Await: Good Night Quotes | Dream Bigly</title>
        <meta
          name="description"
          content="Our good night quotes will help you relax and find inspiration as you wind down your day. Find inspirational and calming sayings to help you sleep well."
        />
        <link
          rel="canonical"
          href="https://dreambigly.in/good-night-quotes"
        />
        <meta
          name="keywords"
          content="good night quotes, best night quotes, good night caption, good quotes about night, good night wishes, good night photo quotes"
        />
        <meta
          name="robots"
          content="index, follow, max-image-preview:large, max-snippet:-1"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <GoodNightQuote
        data={data}
        itemsPerPage={itemsPerPage}
        page={page}
        currentPage={currentPage}
        totalPages={totalPages}
      />
    </>
  );
}

export default GoodNightQuotes;
