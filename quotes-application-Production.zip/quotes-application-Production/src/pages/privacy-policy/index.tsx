import Head from "next/head";
import styles from "@/styles/Home.module.scss";
import PrivacyPolicys from "@/components/Pages/PrivacyPolicy";

const PrivacyPolicy: React.FC = () => {
  return (
    <>
      <Head>
        <title>Privacy Policy - Your Data, Your Privacy | Dream Bigly</title>
        <meta
          name="description"
          content="At Dream Bigly, we value your privacy. Read our comprehensive Privacy Policy to understand how we protect your personal information and ensure a secure online experience."
        />
        <link
          rel="canonical"
          href="https://dreambigly.in/privacy-policy"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <meta name="robots" content="noindex, nofollow" />
      </Head>
      <main>
        <PrivacyPolicys />
      </main>
    </>
  );
};

export default PrivacyPolicy;
