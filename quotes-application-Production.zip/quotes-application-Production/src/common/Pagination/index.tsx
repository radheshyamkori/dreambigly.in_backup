import Link from 'next/link';
import { useRouter } from 'next/router';

export default function Pagination(currentPage: any, totalPages: any) {

    const route = useRouter();

    const CurrentPath = route.pathname

    // console.log(route.pathname,"route")
    const isFirstPage = currentPage.currentPage === 1;
    const isLastPage = currentPage.currentPage === currentPage.totalPages;

    const prevPage = currentPage.currentPage - 1;
    const nextPage = currentPage.currentPage + 1;

    // console.log(currentPage.totalPages, totalPages, CurrentPath)

    return (
        <div className="flex items-center justify-end border-t mt-8 border-gray-200 bg-white px-4 py-3 sm:px-6">
            <div className="flex flex-1 justify-between sm:hidden">
                {!isFirstPage && (
                    <Link
                        href={`${CurrentPath === "/" ? "" : CurrentPath}/?page=${prevPage}`}
                        className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                    >
                        Previous
                    </Link>
                )}
                {!isLastPage && (
                    <Link
                        href={`${CurrentPath === "/" ? "" : CurrentPath}/?page=${nextPage}`}
                        className="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                    >
                        Next
                    </Link>
                )}
            </div>
            <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-end">

                <div>
                    <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
                        {!isFirstPage && (
                            <Link
                                href={`${CurrentPath === "/" ? "" : CurrentPath}/?page=${prevPage}`}
                                className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                            >
                                <span className="sr-only">Previous</span>
                                Previous
                            </Link>
                        )}
                        {[...Array(currentPage.totalPages)].map((_, index) => (
                            <Link
                                key={index}
                                href={`${CurrentPath === "/" ? "" : CurrentPath}/?page=${index + 1}`}
                                aria-current={currentPage.currentPage === index + 1 ? 'page' : undefined}
                                className={`relative ${currentPage.currentPage === index + 1
                                    ? 'z-10 bg-[#296f77] text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#296f77]'
                                    : 'text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:outline-offset-0'
                                    } inline-flex items-center px-4 py-2 text-sm font-semibold`}
                            >
                                {index + 1}
                            </Link>
                        ))}
                        {!isLastPage && (
                            <Link
                                href={`${CurrentPath === "/" ? "" : CurrentPath}/?page=${nextPage}`}
                                className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                            >
                                <span className="sr-only">Next</span>
                                Next
                            </Link>
                        )}
                    </nav>
                </div>
            </div>
        </div>
    );
}
