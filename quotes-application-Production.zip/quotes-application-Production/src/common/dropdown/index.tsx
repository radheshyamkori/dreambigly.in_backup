import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';

interface DropdownProps {
  title: string;
  LinkList: Array<{ route: string; name: string }>;
}

const Dropdown: React.FC<DropdownProps> = ({ title, LinkList }) => {
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const [isDropdown, setIsDropdown] = useState<boolean>(false);

  // Function to close the dropdown when a click occurs outside of it
  const handleClickOutside = (event: MouseEvent) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
      setIsDropdown(false);
    }
  };

  useEffect(() => {
    const handleClick = (event: MouseEvent) => handleClickOutside(event);
    
    if (isDropdown) {
      document.addEventListener('mousedown', handleClick);
    } else {
      document.removeEventListener('mousedown', handleClick);
    }

    return () => {
      document.removeEventListener('mousedown', handleClick);
    };
  }, [isDropdown]);

  const dropdownHandle = (): void => {
    setIsDropdown(!isDropdown);
  };

  const dropdownHandleClose = (): void => {
    setIsDropdown(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        className="flex items-center text-sm font-medium text-gray-900 md:mr-0"
        type="button"
        onClick={dropdownHandle}
      >
        {title}
        {
          <svg
            data-accordion-icon
            className={`w-2.5 h-2.5 ${!isDropdown && 'rotate-180'} ml-2.5 shrink-0`}
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 10 6"
          >
            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5 5 1 1 5" />
          </svg>
        }
      </button>
      {isDropdown && (
        <div className={`z-10 md:absolute relative md:top-12 top-3 overflow-hidden bg-white divide-y divide-gray-100 p-1 md:shadow w-52`}>
          <ul className="text-sm text-gray-700">
            {LinkList &&
              LinkList.map((item, key) => (
                <li key={key}>
                  <Link
                    href={item.route}
                    legacyBehavior // Pass this prop for Link to work properly
                  >
                    <span
                      className="block cursor-pointer px-4 py-2 hover:bg-[#296f77] hover:text-white hover:shadow-lg ease-in-out duration-300"
                      onClick={dropdownHandleClose}
                    >
                      {item.name}
                    </span>
                  </Link>
                </li>
              ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Dropdown;
