import Image from "next/image";
import React from "react";
import Button from "../Button";
import Dummy from "../../Accects/Images/dummy.webp";

interface CardProps {
  image: string;
  alt: string;
  DownloadImageHandle: (image: string) => void;
}

const ImageCard: React.FC<CardProps> = ({
  image,
  alt,
  DownloadImageHandle,
}) => {
  // console.log(itemKey,"keykeykey")
  const isValidUrl = (image: string) => {
    try {
      return Boolean(new URL(image));
    } catch (e) {
      return false;
    }
  };

  // console.log(isValidUrl, "isValidUrl")
  return (
    <div className="rounded-md shadow-xl ">
      <div className="h-52">
        <Image
          src={isValidUrl(image) ? image : Dummy}
          alt={alt}
          height={180}
          width={180}
          sizes="100vw"
          className="w-full h-52 object-cover object-center rounded-t-md rounded-r-md rounded-b-none rounded-none"
        />
      </div>
      <div className="py-3 px-5 flex justify-center">
        <Button
          title={`download`}
          onClick={() => DownloadImageHandle(image)}
          type="button"
          disabled={isValidUrl(image) ? false : true}
        />
      </div>
    </div>
  );
};

export default ImageCard;
