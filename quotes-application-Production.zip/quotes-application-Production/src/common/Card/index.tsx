import React from "react";
import Button from "../Button";

interface Product {
  id: number;
  title: string;
  create_at: string;
}

interface CardProps {
  product: Product;
  copyToClipboard: (title: string, id: number) => void;
  isCopied: number | null;
}

const Card: React.FC<CardProps> = ({ product, copyToClipboard, isCopied }) => {
  const truncate = (val: string) => {
    return val.length > 103 ? val.substring(0, 100) + "..." : val;
  };
  return (
    <div
      className="group relative rounded-md shadow-lg overflow-hidden"
    >
      <div className="px-5 py-4 bg-[#e4e8e8]">
        <div className="h-28">
          <h3 className="text-sm text-slate-600 font-medium">
            {truncate(product.title)}
          </h3>
        </div>
        <Button
          title={Number(isCopied) === product.id ? "copied" : "copy"}
          onClick={() => copyToClipboard(product.title, product.id)}
          type="button"
          disabled={false}
        />
      </div>
    </div>
  );
};

export default Card;
