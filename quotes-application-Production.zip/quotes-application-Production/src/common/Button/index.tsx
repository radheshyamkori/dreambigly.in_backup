import React from 'react';

type Props = {
    title: string;
    onClick: () => void; // Change to the appropriate function signature.
    type: string;
    disabled: boolean; // Corrected the typo here.
};

const Button = (props: Props) => {
    return (
        <button className="rounded-3xl py-2 uppercase px-4 text-[12px] leading-[13px] font-normal text-white bg-[#296f77]" disabled={props.disabled} onClick={props.onClick}>
            {props.title}
        </button>
    );
};

export default Button;
