export const DropdownList: Array<{ id: number; name: string; route: string }> =
  [
    {
      id: 2,
      name: "Positive Attitude Quotes",
      route: "/positive-attitude-quotes",
    },

    {
      id: 5,
      name: "Morning Quotes",
      route: "/morning-quotes",
    },
    {
      id: 6,
      name: "Love Quotes",
      route: "/love-quotes",
    },
    {
      id: 7,
      name: "Birthday Quotes",
      route: "/birthday-quotes",
    },
    {
      id: 8,
      name: "Good Night Quotes",
      route: "/good-night-quotes",
    },
    {
      id: 9,
      name: "Sad Quotes",
      route: "/sad-quotes",
    },
    {
      id: 10,
      name: "Funny Quotes",
      route: "/funny-quotes",
    },
    {
      id: 1,
      name: "Success Quotes",
      route: "/success-quotes",
    },
    {
      id: 3,
      name: "Hindi Motivational Quotes",
      route: "/hindi-motivational-quotes",
    },
    {
      id: 4,
      name: "Urdu Motivational Quotes",
      route: "/urdu-motivational-quotes",
    },
  ];

export const bannerCard: Array<{
  id: number;
  name: string;
  iconName: string;
  route: string;
}> = [
  {
    id: 2,
    iconName: "PositiveAttitude",
    name: "Positive Attitude Quotes",
    route: "/positive-attitude-quotes",
  },
  {
    id: 5,
    iconName: "Morning",
    name: "Morning Quotes",
    route: "/morning-quotes",
  },
  {
    id: 6,
    iconName: "Love",
    name: "Love Quotes",
    route: "/love-quotes",
  },
  {
    id: 7,
    iconName: "Birthday",
    name: "Birthday Quotes",
    route: "/birthday-quotes",
  },
  {
    id: 8,
    iconName: "GoodNight",
    name: "Good Night Quotes",
    route: "/good-night-quotes",
  },
  {
    id: 9,
    iconName: "Sad",
    name: "Sad Quotes",
    route: "/sad-quotes",
  },
  {
    id: 10,
    iconName: "Beauty",
    name: "Funny Quotes",
    route: "/funny-quotes",
  },
  {
    id: 3,
    iconName: "HindiMotivational",
    name: "Hindi Motivational Quotes",
    route: "/hindi-motivational-quotes",
  },
  {
    id: 4,
    iconName: "UrduMotivational",
    name: "Urdu Motivational Quotes",
    route: "/urdu-motivational-quotes",
  },
  {
    id: 1,
    iconName: "Success",
    name: "Success Quotes",
    route: "/success-quotes",
  },
];
