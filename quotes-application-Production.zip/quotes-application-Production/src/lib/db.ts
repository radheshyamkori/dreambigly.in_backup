import { createConnection, PoolConnection, createPool, Pool, Connection, RowDataPacket } from 'mysql2/promise';

let pool: Pool;

export const createDatabasePool = async () => {
    try {
        pool = await createPool({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_DATABASE,
            waitForConnections: true,
            connectionLimit: 1000, // Adjust this according to your needs
        });
    } catch (error) {
        console.error('Error creating database pool:', error);
        throw new Error('Error creating database pool');
    }
    
};

export const connectDatabase = async (): Promise<PoolConnection> => {
    if (!pool) {
        await createDatabasePool(); // Wait for pool creation
    }
    try {
        return await pool.getConnection();
    } catch (error) {
        console.error('Error getting database connection:', error);
        throw new Error('Error getting database connection');
    }
};

export const closeConnection = (connection: PoolConnection) => {
    if (pool) {
        try {
            connection.release(); // Release the connection back to the pool
        } catch (error) {
            console.error('Error releasing connection:', error);
        }
    }
};


// export const fetchDataFromDatabase = async (tableName: string, where: any) => {
//     try {
//         const db = await connectDatabase();
//         const [rows] = await db.query<RowDataPacket[]>(`SELECT * FROM ${tableName} WHERE ${where ? where : 1} ORDER BY ${`id`} DESC`);
//         return rows;
//     } catch (error) {
//         console.error('Error fetching data:', error);
//         throw new Error('Error fetching data');
//     }
// };
export const fetchDataFromDatabase = async (
    tableName: string,
    where: any,
    page: any,
    itemsPerPage: any
) => {
    try {
        const db = await connectDatabase();
        const offset = (page - 1) * itemsPerPage;
        const [rows] = await db.query<RowDataPacket[]>(
            `SELECT * FROM ${tableName} WHERE ${where ? where : 1} ORDER BY ${`id`} DESC LIMIT ?, ?`,
            [offset, itemsPerPage]
        );
        return rows;
    } catch (error) {
        console.error('Error fetching data:', error);
        throw new Error('Error fetching data');
    }
};



export const getTotalItemsFromDatabase = async (
    tableName: string,
    where: any,
) => {
    try {
        const db = await connectDatabase();
        const [result]: any = await db.query(`SELECT COUNT(*) as total FROM ${tableName} WHERE ${where ? where : 1}`);
        return result[0].total;
    } catch (error) {
        console.error('Error fetching total items:', error);
        throw new Error('Error fetching total items');
    }
};