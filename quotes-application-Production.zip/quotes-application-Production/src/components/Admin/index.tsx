import { signOut } from "next-auth/react";
import React, { useState, ChangeEvent, MouseEvent } from "react";

interface QuotesInfo {
  category: string;
  quotesMessage: string;
  image: string;
}

interface ErrorInfo {
  category: boolean;
  quotesMessage: boolean;
  image: boolean;
}

const AdminForm: React.FC = (session: any) => {
  const [quotesInfo, setQuotesInfo] = useState<QuotesInfo>({
    category: "",
    quotesMessage: "",
    image: "",
  });

  const [error, setError] = useState<ErrorInfo>({
    category: false,
    quotesMessage: false,
    image: false,
  });

  const handleInputChange = (
    event: ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = event.target;
    setQuotesInfo({
      ...quotesInfo,
      [name]: value,
    });
    // Clear the error for the current field
    setError({
      ...error,
      [name]: false,
    });
  };

  const handleSubmit = async (e: MouseEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Validate the form fields
    const validationErrors: ErrorInfo = {
      category: !quotesInfo.category,
      quotesMessage: !quotesInfo.quotesMessage,
      image: !quotesInfo.image,
    };

    // Check if any validation errors exist
    if (Object.values(validationErrors).some((error) => error)) {
      setError(validationErrors);
      return;
    }

    // Send the data to the server to insert into the database
    try {
      const response = await fetch("/api/fetch-data", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(quotesInfo),
      });

      if (response.ok) {
        // Quote successfully added to the database, handle accordingly
        // console.log("Quote added successfully");
        setQuotesInfo({
          category: "",
          quotesMessage: "",
          image: "",
        });
        // You can reset the form or show a success message here
      } else {
        // Handle the error if something went wrong during the insertion
        console.error("Failed to add the quote to the database");
      }
    } catch (error) {
      console.error("Error while submitting the form:", error);
    }
  };

  const cancelSubmit = () => {
    setQuotesInfo({
      category: "",
      quotesMessage: "",
      image: "",
    });
    setError({
      category: false,
      quotesMessage: false,
      image: false,
    });
  };

//   console.log(quotesInfo, "quotesInfo");
  return (
    <div className="container mx-auto md:px-7 lg:px-72">
      <div className="bg-white p-5 md:my-6 rounded-md shadow-none md:shadow-xl">
        <div className="">
          <div className="flex justify-between items-center">
            <h2 className="text-base font-semibold leading-7 text-gray-900">
              Quote Info
            </h2>
            <button
              onClick={() => signOut()}
              className="rounded-md bg-[#296f77] px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#94CFBA] ease-in-out duration-200 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 "
            >
              sign out
            </button>
          </div>
        </div>
        <form className="mt-2" onSubmit={handleSubmit}>
          <div className="border-b border-gray-900/10 pb-12 mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
            <div className="col-span-full">
              <label
                htmlFor="category"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Quote Category
              </label>
              <div className="mt-2">
                <div className="flex rounded-md shadow-sm ring-1 ring-inset ring-gray-300 ">
                  <select
                    id="category"
                    name="category"
                    value={quotesInfo.category}
                    onChange={handleInputChange}
                    className="block flex-1 border-0 bg-transparent py-2 pl-3 text-gray-900 placeholder:text-gray-400 w-full focus:ring-0 sm:text-sm sm:leading-6"
                  >
                    <option value="">select category</option>
                    <option value="Success Quotes">Success Quotes</option>
                    <option value="Positive Attitude Quotes">
                      Positive Attitude Quotes
                    </option>
                    <option value="Hindi Motivational Quotes">
                      Hindi Motivational Quotes
                    </option>
                    <option value="Urdu Motivational Quotes">
                      Urdu Motivational Quotes
                    </option>
                    <option value="Morning Quotes">Morning Quotes</option>
                    <option value="Love Quotes">Love Quotes</option>
                    <option value="Birthday Quotes">Birthday Quotes</option>
                    <option value="Good Night Quotes">Good Night Quotes</option>
                    <option value="Sad Quotes">Sad Quotes</option>
                    <option value="Funny Quotes">Funny Quotes</option>
                  </select>
                </div>
                {error.category && (
                  <p className="text-red-500 text-xs mt-1">
                    Category is required
                  </p>
                )}
              </div>
            </div>
            <div className="col-span-full">
              <label
                htmlFor="image"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Image Url
              </label>
              <div className="mt-2">
                <div className="flex rounded-md shadow-sm ring-1 ring-inset ring-gray-300 ">
                  <input
                    type="text"
                    id="image"
                    name="image"
                    value={quotesInfo.image}
                    onChange={handleInputChange}
                    autoComplete="image"
                    className="block flex-1 border-0 bg-transparent py-1.5 pl-3 text-gray-900 placeholder:text-gray-400 w-full focus:ring-0 sm:text-sm sm:leading-6"
                    placeholder="Enter Your Image Url"
                  />
                </div>
              </div>
              {error.image && (
                <p className="text-red-500 text-xs mt-1">
                  Image URL is required
                </p>
              )}
            </div>

            <div className="col-span-full">
              <label
                htmlFor="quotesMessage"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Quote Message
              </label>
              <div className="mt-2">
                <textarea
                  id="quotesMessage"
                  name="quotesMessage"
                  rows={3}
                  value={quotesInfo.quotesMessage || ""}
                  onChange={handleInputChange}
                  className="block w-full rounded-md border-0 py-1.5 pl-3 text-gray-900 shadow-sm ring-1 ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-rose-600 sm:text-sm sm:leading-6"
                  placeholder="Enter Your Quote"
                />
              </div>
              {error.quotesMessage && (
                <p className="text-red-500 text-xs mt-1">
                  Quote Message is required
                </p>
              )}
            </div>
          </div>
          <div className="mt-6 flex items-center justify-end gap-x-6">
            <button
              type="button"
              onClick={cancelSubmit}
              className="text-sm font-semibold leading-6 text-gray-900"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-md bg-[#296f77] px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#94CFBA] ease-in-out duration-200 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
export default AdminForm;
