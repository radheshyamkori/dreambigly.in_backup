import React from "react";
import Footer from "../Footer";
import Header from "../Header";
import { useRouter } from "next/router";

type LayoutProps = {
    children: React.ReactNode;
};

const Layout: React.FC<LayoutProps> = ({ children }) => {
    const router = useRouter();

    // Check if we're on an error page
    const isErrorPage = router.pathname === "/404";

    // console.log(router, "isErrorPage")
    return (
        <div>
            {!isErrorPage && <Header />}
            <main>{children}</main>
            {!isErrorPage && <Footer />}
        </div>
    );
};

export default Layout;
