import React, { useState } from "react";
import styles from "./SuccessQuote.module.scss";
import Card from "@/common/Card";
import Pagination from "@/common/Pagination";
import ImageCard from "@/common/Card/ImageCard";
import Link from "next/link";
import { useRouter } from "next/router";

interface DataItem {
  id: number;
  title: string;
  image: string;
  create_at: string; // Assuming create_at is a string (in ISO format)
}
interface HomeProps {
  data: DataItem[];
  page: string | string[];
  itemsPerPage: number;
  currentPage?: number; // Optional
  totalPages?: number;
}
const products = [
  {
    id: 1,
    title: 'अक्सर वही बात रुलाती है, जिनके जवाब में हम कहते है "कोई बात नही"💯',
    imageSrc:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 2,
    title: 'अक्सर वही बात रुलाती है, जिनके जवाब में हम कहते है "कोई बात नही"💯',
    imageSrc:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 3,
    title:
      "आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹",
    imageSrc:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 4,
    title:
      "आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹",
    imageSrc:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 5,
    title:
      "आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹",
    imageSrc:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 6,
    title:
      "आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹",
    imageSrc:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 7,
    title:
      "आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹",
    imageSrc:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 8,
    title:
      "आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹",
    imageSrc:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  // More products...
];

const PositiveAttitudeQuote = ({
  itemsPerPage,
  currentPage,
  page,
  totalPages,
  data,
}: HomeProps) => {
  const [isActive, setIsActive] = useState<string>("latest");
  const router = useRouter();
  const TabHandle = (id: string) => {
    setIsActive(id);
  };

  const [isCopied, setIsCopied] = useState<number | null>(null);

  const copyToClipboard = (textToCopy: string, id: number) => {
    const textarea = document.createElement("textarea");
    textarea.value = textToCopy;
    textarea.style.position = "fixed";

    document.body.appendChild(textarea);
    textarea.select();

    try {
      document.execCommand("copy");
      setIsCopied(id);
    } catch (err) {
      console.error("Failed to copy:", err);
    } finally {
      document.body.removeChild(textarea);
      setTimeout(() => {
        setIsCopied(null);
      }, 2000);
    }
  };

  const DownloadImageHandle = async (image: string) => {
    const downloadUrl = `/api/download?image=${encodeURIComponent(image)}`;

    // Trigger download by navigating to the serverless function
    router.push(downloadUrl);
  };

  // console.log(data, "data line 123");

  return (
    <>
      <section className={`${styles.success_quote}`}>
        <div className="container mx-auto px-6 xl:px-7 h-full">
          <div className="flex flex-col gap-y-3 md:gap-y-6 items-center py-10 text-center justify-center h-full relative">
            <nav className="flex absolute top-4 left-0" aria-label="Breadcrumb">
              <ol className="inline-flex items-center space-x-1 md:space-x-3">
                <li className="inline-flex items-center">
                  <Link
                    href="https://dreambigly.in/"
                    className="inline-flex items-center text-sm font-medium text-white hover:text-[#296f77]"
                  >
                    <svg
                      className="w-3 h-3 mr-2.5"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                  </Link>
                </li>
                <li aria-current="page">
                  <div className="flex items-center">
                    <svg
                      className="w-3 h-3 text-gray-400 mx-1"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 6 10"
                    >
                      <path
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="m1 9 4-4-4-4"
                      />
                    </svg>
                    <span className="ml-1 text-sm font-medium text-gray-500 md:ml-2 dark:text-gray-400">
                      Positive Attitude Quotes
                    </span>
                  </div>
                </li>
              </ol>
            </nav>

            <h1 className="text-xl md:text-4xl font-semibold text-white mt-6 md:mt-0">
              Positive Attitude Quotes
            </h1>
            <p className="text-xs md:text-base text-white">
              Elevate Your Mindset, Accept Optimism, and Transform Your Life
              with Inspirational Wisdom: Cultivate Positivity with Positive
              Attitude Quotes.
            </p>
          </div>
        </div>
      </section>
      <div className="container mx-auto xl:px-7">
        <div
          className={`bg-white mt-0 lg:-mt-10 rounded-md z-3 relative pb-10`}
        >
          <div className="mb-4 border-b border-gray-200 dark:border-white">
            <ul className="grid grid-cols-2 -mb-px text-sm font-medium text-center">
              <li className="mr-2 w-full" role="presentation">
                <button
                  onClick={() => TabHandle("latest")}
                  className={`inline-block w-full p-4 ${
                    isActive === "latest" && "border-b-2 border-[#296f77]"
                  } rounded-t-lg`}
                  type="button"
                  role="tab"
                >
                  Latest Quotes
                </button>
              </li>
              <li className="mr-2 w-full" role="presentation">
                <button
                  onClick={() => TabHandle("trending")}
                  className={`w-full inline-block p-4 ${
                    isActive === "trending" && "border-b-2 border-[#296f77]"
                  } rounded-t-lg `}
                  type="button"
                >
                  Images Quotes
                </button>
              </li>
            </ul>
          </div>
          <div className=" grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8 mx-auto  max-w-2xl px-4 sm:px-6 lg:max-w-7xl lg:px-16">
            {isActive === "latest"
              ? data.map((item, key) => (
                  <React.Fragment key={key}>
                    <Card
                      product={item}
                      copyToClipboard={copyToClipboard}
                      isCopied={isCopied}
                    />
                  </React.Fragment>
                ))
              : isActive === "trending"
              ? data.map((item, key) => (
                  <React.Fragment key={key}>
                    <ImageCard
                      image={item.image}
                      alt={item.title}
                      DownloadImageHandle={DownloadImageHandle}
                    />
                  </React.Fragment>
                ))
              : ""}
          </div>
          {data.length > 0 && (
            <Pagination currentPage={currentPage} totalPages={totalPages} />
          )}
        </div>
      </div>
    </>
  );
};

export default PositiveAttitudeQuote;
