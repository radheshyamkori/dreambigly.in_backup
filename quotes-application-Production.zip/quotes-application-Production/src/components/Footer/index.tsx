import Image from "next/image";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import styles from "./footer.module.scss";
import Logo from "../../Accects/Images/logo.svg";
import WhatIcon from "../../Accects/Images/wp.png";
import { DropdownList } from "../../constant/constant";

type Props = {};

const Footer = (props: Props) => {
  const [showIcon, setShowIcon] = useState(true);

  useEffect(() => {
    let lastScrollPosition = window.scrollY;

    const handleScroll = () => {
      const currentScrollPosition = window.scrollY;

      // Check the scroll direction
      if (currentScrollPosition > lastScrollPosition) {
        // Scrolling down
        setShowIcon(true);
      } else {
        // Scrolling up
        setShowIcon(false);
      }

      lastScrollPosition = currentScrollPosition;
    };

    // Attach the scroll event listener when the component mounts
    window.addEventListener("scroll", handleScroll);

    // Clean up the event listener when the component unmounts
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const handleIconClick = () => {
    // Replace '123456789' with the actual phone number you want to redirect to
    // const phoneNumber = '123456789';

    // Construct the WhatsApp link
    const whatsappLink = `https://www.whatsapp.com/channel/0029Va9OHGf77qVLa03bEk08`;

    // Redirect to WhatsApp
    // window.location.href = whatsappLink;
    window.open(whatsappLink, "_blank");
  };

  return (
    <>
      <footer className="bg-slate-300 mt-11">
        <div className="mx-auto px-4 lg:max-w-7xl md:px-8">
          <div
            className={`grid md:gap-16 gap-8 pt-6 lg:pt-8 ${styles.grid_layout}`}
          >
            <div className="col-span-2 md:col-span-1 mb-4">
              <div className="relative w-36">
                <Link href="/">
                  <Image
                    src={Logo}
                    alt="brand logo"
                    sizes="100vw"
                    className="w-full h-20"
                  />
                </Link>
              </div>
              <p className="text-gray-500 font-medium text-sm mt-3 ps-[16px]">
                Welcome to DreamBigly.in, where inspiration, motivation, and
                profound wisdom come to life through the art of quotes. Our
                website has been intentionally constructed to be your haven,
                with a broad selection of quotes capturing the complete range of
                human emotions, topics, and the many tapestries of life's
                experiences. Whether you're in search of a daily dose of
                positivity, the fuel to pursue your aspirations or a heartfelt
                message to share with those you cherish, we've got you covered.
              </p>
            </div>
            <div>
              <h2 className="mb-6 text-sm font-semibold text-gray-900 uppercase">
                Quotes
              </h2>
              <ul className="text-gray-500 font-medium">
                {DropdownList.slice(0, 7).map((item, key) => (
                  <React.Fragment key={key}>
                    <li className="mb-4">
                      <Link
                        href={item.route}
                        className=" text-sm font-normal text-gray-500 hover:underline hover:text-[#296f77]"
                      >
                        {item.name}
                      </Link>
                    </li>
                  </React.Fragment>
                ))}
              </ul>
            </div>

            <div>
              <h2 className="mb-6 text-sm font-semibold text-gray-900 uppercase">
                Motivational Quotes
              </h2>
              <ul className="text-gray-500 font-medium">
                {DropdownList.slice(7).map((item, key) => (
                  <React.Fragment key={key}>
                    <li className="mb-4">
                      <Link
                        href={item.route}
                        className=" text-sm font-normal text-gray-500 hover:underline hover:text-[#296f77] ease-in-out duration-500"
                      >
                        {item.name}
                      </Link>
                    </li>
                  </React.Fragment>
                ))}
              </ul>
            </div>

            <div>
              <h2 className="mb-6 text-sm font-semibold text-gray-900 uppercase">
                Legal
              </h2>
              <ul className="text-gray-500 font-medium">
                <li className="mb-4">
                  <Link
                    href="/privacy-policy/"
                    className="text-sm font-normal text-gray-500 hover:underline hover:text-[#296f77] ease-in-out duration-500"
                  >
                    Privacy Policy
                  </Link>
                </li>
                <li className="mb-4">
                  <Link
                    href="/about-us/"
                    className="text-sm font-normal text-gray-500 hover:underline hover:text-[#296f77] ease-in-out duration-500"
                  >
                    About Us
                  </Link>
                </li>
                {/* <li className="mb-4">
                  <Link
                    href="/blog/"
                    className="text-sm font-normal text-gray-500 hover:underline hover:text-[#296f77] ease-in-out duration-500"
                  >
                    Blog
                  </Link>
                </li> */}
              </ul>
            </div>
            <div>
              {/* <h2 className="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">
                Download
              </h2>
              <ul className="text-gray-500 font-medium">
                <li className="mb-4">
                  <Link
                    href="#"
                    className="text-sm font-normal text-gray-500 hover:underline"
                  >
                    iOS
                  </Link>
                </li>
                <li className="mb-4">
                  <Link
                    href="#"
                    className="text-sm font-normal text-gray-500 hover:underline"
                  >
                    Android
                  </Link>
                </li>
                <li className="mb-4">
                  <Link
                    href="#"
                    className="text-sm font-normal text-gray-500 hover:underline"
                  >
                    Windows
                  </Link>
                </li>
                <li className="mb-4">
                  <Link
                    href="#"
                    className="text-sm font-normal text-gray-500 hover:underline"
                  >
                    MacOS
                  </Link>
                </li>
              </ul> */}
            </div>
          </div>
        </div>
        <div className="bg-slate-200">
          <div className=" justify-between px-4 py-3 mx-auto lg:max-w-7xl md:items-center md:flex md:px-8">
            <ul className="flex text-center justify-center md:items-center md:justify-center space-x-4 space-y-0 md:flex md:space-x-6 md:space-y-0">
              <li className="text-sm font-normal text-gray-500">
                Dream Bigly@copyright 2024
              </li>
              {/* <li className="text-sm font-normal text-gray-500">
                <Link href="site-map">Site Map</Link>
              </li> */}
            </ul>

            <div className="flex mt-5 space-x-4 items-center justify-center sm:justify-center md:mt-0">
              <Link
                href="https://www.instagram.com/dreambigly_in/"
                className="text-gray-400 hover:text-gray-900"
              >
                <svg
                  width="28px"
                  height="28px"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 7.90001C11.1891 7.90001 10.3964 8.14048 9.72218 8.59099C9.04794 9.0415 8.52243 9.68184 8.21211 10.431C7.90179 11.1802 7.8206 12.0046 7.9788 12.7999C8.13699 13.5952 8.52748 14.3258 9.10088 14.8992C9.67427 15.4725 10.4048 15.863 11.2001 16.0212C11.9955 16.1794 12.8198 16.0982 13.569 15.7879C14.3182 15.4776 14.9585 14.9521 15.409 14.2779C15.8596 13.6036 16.1 12.8109 16.1 12C16.1013 11.4612 15.9962 10.9275 15.7906 10.4295C15.585 9.93142 15.2831 9.47892 14.9021 9.09794C14.5211 8.71695 14.0686 8.415 13.5706 8.20942C13.0725 8.00385 12.5388 7.8987 12 7.90001ZM12 14.67C11.4719 14.67 10.9557 14.5134 10.5166 14.22C10.0776 13.9267 9.73534 13.5097 9.53326 13.0218C9.33117 12.5339 9.2783 11.9971 9.38132 11.4791C9.48434 10.9612 9.73863 10.4854 10.112 10.112C10.4854 9.73863 10.9612 9.48434 11.4791 9.38132C11.9971 9.2783 12.5339 9.33117 13.0218 9.53326C13.5097 9.73534 13.9267 10.0776 14.22 10.5166C14.5134 10.9557 14.67 11.4719 14.67 12C14.67 12.7081 14.3887 13.3873 13.888 13.888C13.3873 14.3887 12.7081 14.67 12 14.67ZM17.23 7.73001C17.23 7.9278 17.1714 8.12114 17.0615 8.28558C16.9516 8.45003 16.7954 8.57821 16.6127 8.65389C16.43 8.72958 16.2289 8.74938 16.0349 8.7108C15.8409 8.67221 15.6628 8.57697 15.5229 8.43712C15.3831 8.29727 15.2878 8.11909 15.2492 7.92511C15.2106 7.73112 15.2304 7.53006 15.3061 7.34733C15.3818 7.16461 15.51 7.00843 15.6744 6.89855C15.8389 6.78866 16.0322 6.73001 16.23 6.73001C16.4952 6.73001 16.7496 6.83537 16.9371 7.02291C17.1247 7.21044 17.23 7.4648 17.23 7.73001ZM19.94 8.73001C19.9691 7.48684 19.5054 6.28261 18.65 5.38001C17.7522 4.5137 16.5474 4.03897 15.3 4.06001C14 4.00001 10 4.00001 8.70001 4.06001C7.45722 4.0331 6.25379 4.49652 5.35001 5.35001C4.49465 6.25261 4.03093 7.45684 4.06001 8.70001C4.00001 10 4.00001 14 4.06001 15.3C4.03093 16.5432 4.49465 17.7474 5.35001 18.65C6.25379 19.5035 7.45722 19.9669 8.70001 19.94C10.02 20.02 13.98 20.02 15.3 19.94C16.5432 19.9691 17.7474 19.5054 18.65 18.65C19.5054 17.7474 19.9691 16.5432 19.94 15.3C20 14 20 10 19.94 8.70001V8.73001ZM18.24 16.73C18.1042 17.074 17.8993 17.3863 17.6378 17.6478C17.3763 17.9093 17.064 18.1142 16.72 18.25C15.1676 18.5639 13.5806 18.6715 12 18.57C10.4228 18.6716 8.83902 18.564 7.29001 18.25C6.94608 18.1142 6.63369 17.9093 6.37223 17.6478C6.11076 17.3863 5.90579 17.074 5.77001 16.73C5.35001 15.67 5.44001 13.17 5.44001 12.01C5.44001 10.85 5.35001 8.34001 5.77001 7.29001C5.90196 6.94268 6.10547 6.62698 6.36733 6.36339C6.62919 6.09981 6.94355 5.89423 7.29001 5.76001C8.83902 5.44599 10.4228 5.33839 12 5.44001C13.5806 5.33856 15.1676 5.44616 16.72 5.76001C17.064 5.89579 17.3763 6.10076 17.6378 6.36223C17.8993 6.62369 18.1042 6.93608 18.24 7.28001C18.66 8.34001 18.56 10.84 18.56 12C18.56 13.16 18.66 15.67 18.24 16.72V16.73Z"
                    fill="#000000"
                  />
                </svg>
                <span className="sr-only">Instagram page</span>
              </Link>
              <Link
                href="https://twitter.com/DreamBigly/"
                className="text-gray-400 hover:text-gray-900"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  x="0px"
                  y="0px"
                  width="28px"
                  height="28px"
                  viewBox="0 0 30 30"
                className="w-[22px] h-[22px]"
                >
                  <path d="M26.37,26l-8.795-12.822l0.015,0.012L25.52,4h-2.65l-6.46,7.48L11.28,4H4.33l8.211,11.971L12.54,15.97L3.88,26h2.65 l7.182-8.322L19.42,26H26.37z M10.23,6l12.34,18h-2.1L8.12,6H10.23z"></path>
                </svg>
                <span className="sr-only">pinterest page</span>
              </Link>
              <Link
                href="https://in.pinterest.com/dreambiglyin/"
                className="text-gray-400 hover:text-gray-900"
              >
                <svg
                  className="w-[22px] h-[22px]"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M3.5 12C3.5 7.30558 7.30558 3.5 12 3.5C16.6944 3.5 20.5 7.30558 20.5 12C20.5 16.6944 16.6944 20.5 12 20.5C10.9716 20.5 9.98587 20.3174 9.07345 19.9828C9.64822 18.4359 10.2115 16.8847 10.7517 15.3255C11.326 15.7348 12.0668 16 13 16C14.935 16 16.9749 14.7247 17.4806 12.1961C18.1155 9.02148 15.5728 6 12 6C10.4972 6 9.01887 6.6037 7.91298 7.56243C6.80483 8.52311 6 9.90687 6 11.5C6 12.2746 6.23394 13.1378 6.79149 13.7057C7.17707 14.0919 7.82087 14.0933 8.20711 13.7071C8.59019 13.324 8.59749 12.7074 8.22899 12.3155C7.44315 11.3348 8.47852 9.71907 9.22306 9.07361C9.99585 8.40366 11.0175 8 12 8C14.4272 8 15.8845 9.97852 15.5194 11.8039C15.2165 13.3183 14.065 14 13 14C12.1821 14 11.7416 13.6547 11.4599 13.208C11.6137 12.7237 11.7454 12.2838 11.8387 11.9263C12.0311 11.1886 12.1473 10.3002 11.4839 9.7474C10.9908 9.33644 10.4087 9.42759 10.0528 9.60557C9.39135 9.93629 9 10.7099 9 11.5C9 11.9414 9.06873 12.6253 9.31675 13.3315C8.67824 15.258 7.98579 17.167 7.27924 19.0696C5.00045 17.5449 3.5 14.9477 3.5 12ZM12 1.5C6.20101 1.5 1.5 6.20101 1.5 12C1.5 17.799 6.20101 22.5 12 22.5C17.799 22.5 22.5 17.799 22.5 12C22.5 6.20101 17.799 1.5 12 1.5Z"
                    fill="#000000"
                  />
                </svg>
                <span className="sr-only">twitter account</span>
              </Link>
            </div>
          </div>
        </div>
      </footer>
      <div
        onClick={handleIconClick}
        // href="https://www.whatsapp.com/channel/0029Va9OHGf77qVLa03bEk08"
        className="fixed bottom-24 md:bottom-16 right-5 cursor-pointer"
        style={{ display: showIcon ? "block" : "none" }}
        // target="_blank"
      >
        <Image src={WhatIcon} alt="whatsaap" width={60} height={60} />
      </div>
    </>
  );
};

export default Footer;
