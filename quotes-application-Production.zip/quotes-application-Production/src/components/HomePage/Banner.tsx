import Card from "@/common/Card";
import React, { useState } from "react";
import styles from "./Banner.module.scss";
import ImageCard from "@/common/Card/ImageCard";
import { bannerCard } from "@/constant/constant";
import { useRouter } from "next/router";
import Pagination from "@/common/Pagination";
import Link from "next/link";

interface DataItem {
  id: number;
  title: string;
  image: string;
  create_at: string; // Assuming create_at is a string (in ISO format)
}
interface HomeProps {
  data: DataItem[];
  page: string | string[];
  itemsPerPage: number;
  currentPage?: number; // Optional
  totalPages?: number;
}
// const products = [
//     {
//         id: 1,
//         name: 'अक्सर वही बात रुलाती है, जिनके जवाब में हम कहते है "कोई बात नही"💯',
//         href: '#',
//         imageSrc: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//         imageAlt: "Front of men's अक्सर वही बात रुलाती है, जिनके जवाब में हम कहते है 'कोई बात नही 💯' in black.",
//         price: '$35',
//         color: 'Black',
//     },
//     {
//         id: 2,
//         name: 'अक्सर वही बात रुलाती है, जिनके जवाब में हम कहते है "कोई बात नही"💯',
//         href: '#',
//         imageSrc: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//         imageAlt: "Front of men's अक्सर वही बात रुलाती है, जिनके जवाब में हम कहते है 'कोई बात नही💯' in black.",
//         price: '$35',
//         color: 'Black',
//     },
//     {
//         id: 3,
//         name: 'आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹',
//         href: '#',
//         imageSrc: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//         imageAlt: "Front of men's Choose people who choose you. in black.",
//         price: '$35',
//         color: 'Black',
//     },
//     {
//         id: 4,
//         name: 'आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹',
//         href: '#',
//         imageSrc: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//         imageAlt: "Front of men's Choose people who choose you. in black.",
//         price: '$35',
//         color: 'Black',
//     },
//     {
//         id: 5,
//         name: 'आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹',
//         href: '#',
//         imageSrc: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//         imageAlt: "Front of men's Choose people who choose you. in black.",
//         price: '$35',
//         color: 'Black',
//     },
//     {
//         id: 6,
//         name: 'आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹',
//         href: '#',
//         imageSrc: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//         imageAlt: "Front of men's Choose people who choose you. in black.",
//         price: '$35',
//         color: 'Black',
//     },
//     {
//         id: 7,
//         name: 'आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹',
//         href: '#',
//         imageSrc: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//         imageAlt: "Front of men's Choose people who choose you. in black.",
//         price: '$35',
//         color: 'Black',
//     },
//     {
//         id: 8,
//         name: 'आग लगा दी, आज उस किताब📘 को मैंने, जिसमें लिखा था मोहब्बत, अगर सच्ची हो तो मिलती जरूर है❤️‍🩹',
//         href: '#',
//         imageSrc: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
//         imageAlt: "Front of men's Choose people who choose you. in black.",
//         price: '$35',
//         color: 'Black',
//     },
//     // More products...
// ]

const Banner = ({
  itemsPerPage,
  currentPage,
  page,
  totalPages,
  data,
}: HomeProps) => {
  const router = useRouter();
  const [isCopied, setIsCopied] = useState<number | null>(null);

  const copyToClipboard = (textToCopy: string, id: number) => {
    const textarea = document.createElement("textarea");
    textarea.value = textToCopy;
    textarea.style.position = "fixed";

    document.body.appendChild(textarea);
    textarea.select();

    try {
      document.execCommand("copy");
      setIsCopied(id);
    } catch (err) {
      console.error("Failed to copy:", err);
    } finally {
      document.body.removeChild(textarea);
      setTimeout(() => {
        setIsCopied(null);
      }, 2000);
    }
  };
  // const DownloadImageHandle = (image: string) => {
  //   // //console.log(image, "asdasda");
  //   fetch(image)
  //     .then((response) => response.blob())
  //     .then((blob) => {
  //       const url = window.URL.createObjectURL(new Blob([blob]));
  //       const link = document.createElement("a");
  //       link.href = url;
  //       link.setAttribute("download", "image.jpg"); // Set the desired filename
  //       document.body.appendChild(link);
  //       link.click();
  //     })
  //     .catch((error) => {
  //       console.error("Error downloading image:", error);
  //     });
  // };
  // const router = useRouter();
  const DownloadImageHandle = async (image: string) => {
    const downloadUrl = `/api/download?image=${encodeURIComponent(image)}`;

    // Trigger download by navigating to the serverless function
    router.push(downloadUrl);
  };

  const RedirectHandle = (item: string) => {
    router.push(item);
  };

  return (
    <header>
      <div className={`${styles.Status}`}>
        <ul
          className={`${styles.main_Banner} grid grid-cols-2 py-16 gap-x-6 gap-y-6 sm:grid-cols-3 lg:grid-cols-5 xl:gap-x-8 mx-auto  max-w-2xl px-4 sm:px-6 lg:max-w-7xl lg:px-16`}
        >
          {bannerCard.map((item, key) => (
            <li
              key={key}
              className="cursor-pointer bg-gradient-to-r from-[#296f77]  to-[#94CFBA] text-white py-5 px-4 text-center rounded-lg"
              onClick={() => RedirectHandle(item.route)}
            >
              <i
                className={`${
                  styles[item.iconName]
                } block bg-white cursor-pointer h-10 w-10 m-auto`}
              ></i>
              <h3 className="text-sm mt-2">{item.name}</h3>
            </li>
          ))}
        </ul>
      </div>
      <div className="container mx-auto xl:px-7">
        <div className={`bg-white -mt-10 rounded-md z-3 relative pb-8`}>
          <h1
            className={`text-center text-lg px-1 text-gray-700 md:text-2xl font-medium pt-5 mb-4`}
          >
            Welcome to Dream Bigly <br />
            Your Place for Inspiration and Motivation
          </h1>
          <h2
            className={`text-center text-lg font-medium py-5  ${styles.mainTitle} relative`}
            data-content="Latest Quotes"
          />
          <div className=" grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8 mx-auto  max-w-2xl px-4 sm:px-6 lg:max-w-7xl lg:px-16">
            {data.map((item, key) => (
              <React.Fragment key={key}>
                <Card
                  product={item}
                  copyToClipboard={copyToClipboard}
                  isCopied={isCopied}
                />
              </React.Fragment>
            ))}
          </div>

          <div className="flex flex-1 justify-center mt-9">
            <Link
              href="/success-quotes"
              className="p-2  rounded-full px-6 text-[14px] text-white bg-[#296f77] mb-6"
            >
              More
            </Link>
          </div>
        </div>

        {
          // <Pagination
          //     currentPage={currentPage}
          //     totalPages={totalPages}
          // />
        }
        <div className={`bg-white mt-10 rounded-md z-3 relative mb-10`}>
          <h2
            className={`text-center text-lg font-medium py-5  ${styles.mainTitle} relative`}
            data-content="Latest Images"
          />
          <div className=" grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8 mx-auto  max-w-2xl px-4 sm:px-6 lg:max-w-7xl lg:px-16">
            {data.slice(0, 10).map((item, index) => (
              <React.Fragment key={index}>
                <ImageCard
                  image={item.image}
                  alt={item.title}
                  DownloadImageHandle={DownloadImageHandle}
                />
              </React.Fragment>
            ))}
          </div>
          <div className="flex flex-1 justify-center mt-9">
            <Link
              href="/success-quotes"
              className="p-2  rounded-full px-6 text-[14px] text-white bg-[#296f77] mb-6"
            >
              More
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Banner;
