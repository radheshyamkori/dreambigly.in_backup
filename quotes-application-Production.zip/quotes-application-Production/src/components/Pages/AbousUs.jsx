import Link from "next/link";
import React from "react";

const AbousUs = () => {
  return (
    <div className="mt-5 md:mt-8">
      <div className="conatiner mx-auto px-4 lg:max-w-7xl md:px-8">
        <nav className="flex mb-5" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1 md:space-x-3">
            <li className="inline-flex items-center">
              <Link
                href="https://dreambigly.in/"
                className="inline-flex items-center text-sm font-medium text-slate-700 hover:text-[#296f77]"
              >
                <svg
                  className="w-3 h-3 mr-2.5"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                </svg>
                Home
              </Link>
            </li>
            <li aria-current="page">
              <div className="flex items-center">
                <svg
                  className="w-3 h-3 text-gray-400 mx-1"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 6 10"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="m1 9 4-4-4-4"
                  />
                </svg>
                <span className="ml-1 text-sm font-medium text-gray-500 md:ml-2 dark:text-gray-400">
                  About Us
                </span>
              </div>
            </li>
          </ol>
        </nav>

        <h1 className="md:text-3xl text-xl font-semibold mb-3">
          Welcome to Dream Bigly - Where Dreams Take Center Stage!
        </h1>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          At Dream Bigly, we're not just a website; we're a hub of inspiration,
          motivation, and a dash of humor. Our mission is simple: to infuse your
          days with positivity, fuel your aspirations, and sprinkle a bit of
          laughter into every moment. Here's a glimpse into what we offer across
          various categories:
        </p>
        {/* <p className="text-[#3c4858] mb-8 font-normal text-sm">
          Here at{" "}
          <Link
            href="https://dreambigly.in/"
            className="font-bold text-[#483aca]"
          >
            DreamBigly.in
          </Link>
          , we wholeheartedly believe in the transformative power of words.
          Words have the incredible power to shape lives, ignite the flame of
          hope, and spark profound transformation. Our purpose is
          straightforward: to offer you the appropriate words, exactly when you
          need them, no matter what problems life throws at you. To make this
          quest more manageable, we've thoughtfully arranged our extensive
          collection of quotes into distinct categories, catering to every
          occasion and sentiment:
        </p> */}

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Success Quotes - Because Your Success is Our Success!
        </h2>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          At Dream Bigly, we believe that success isn't just an achievement;
          it's a journey. Our&nbsp;
          <Link href="/success-quotes/" className="font-bold text-[#483aca]">
            success quotes
          </Link>{" "}
          are here to accompany you every step of the way, reminding you that
          the path to success is paved with determination, resilience, and a
          touch of audacity.
        </p>

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Positive Attitude Quotes - Your Daily Dose of Positivity!
        </h2>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          Maintaining a positive attitude is the key to unlocking the doors of
          opportunity. Our{" "}
          <Link
            href="positive-attitude-quotes"
            className="font-bold text-[#483aca]"
          >
            positive attitude quotes
          </Link>{" "}
          are designed to be your daily boost, helping you see the silver lining
          in every cloud and turning challenges into stepping stones towards
          success.
        </p>

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Hindi Motivational Quotes - आपकी मुश्किलें हमारी मोटिवेशन हैं!
        </h2>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          Dream Bigly पर{" "}
          <Link
            href="/hindi-motivational-quotes"
            className="font-bold text-[#483aca]"
          >
            हिंदी मोटिवेशनल कोट्स
          </Link>{" "}
          से आपको वो सहारा मिलेगा जो आपको आगे बढ़ने की सीधी राह दिखाएगा। यहाँ
          आपको मिलेगा मंजिल तक पहुंचने का सही रास्ता।
        </p>

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Urdu Motivational Quotes - ہم آپکی آگے بڑھنے میں آپکے ساتھ ہیں!
        </h2>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          Dream Bigly کی مصروفیت سے بھرا ہوا ہے
          <Link
            href="/urdu-motivational-quotes"
            className="font-bold text-[#483aca]"
          >
            اُردو موٹویشنل کوٹس
          </Link>
          جو آپکو ہر چیلنج کو ایک نیا موقع بنانے میں مدد فراہم کریں گے۔{" "}
        </p>

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Morning Quotes - Because Mornings Should Inspire!
        </h2>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          Begin your day with a dose of inspiration! Our{" "}
          <Link href="/morning-quotes" className="font-bold text-[#483aca]">
            morning quotes
          </Link>
          are crafted to kickstart your day with positivity, setting the tone
          for a day filled with achievements and smiles.
        </p>

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Love Quotes - Spreading Love, One Quote at a Time!
        </h2>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          Love makes the world go 'round, and our{" "}
          <Link href="/love-quotes" className="font-bold text-[#483aca]">
            love quotes{" "}
          </Link>{" "}
          are here to make your heart skip a beat. Whether it's self-love,
          romantic love, or friendship, find the perfect words to express the
          love that fills your life.
        </p>

        <h3 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Birthday Quotes - Celebrate Life, Celebrate You!
        </h3>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          Birthdays are a celebration of life, and our{" "}
          <Link href="/birthday-quotes" className="font-bold text-[#483aca]">
            birthday quotes
          </Link>
          , are here to add a touch of joy to every celebration. From heartfelt
          wishes to humorous quips, make every birthday memorable with our
          collection.
        </p>

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Good Night Quotes - Sweet Dreams, Dreamer!
        </h2>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          As the day winds down, let our{" "}
          <Link href="/good-night-quotes" className="font-bold text-[#483aca]">
            good night quotes
          </Link>
          ,be the gentle lullaby that ushers you into a peaceful night's sleep.
          Close your eyes with positivity, and wake up ready to conquer new
          dreams.
        </p>

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Sad Quotes - Because Even in Darkness, There's Light!
        </h2>
        <p className="text-[#3c4858] mb-8 font-normal text-sm">
          We understand that life has its moments of sorrow. Our{" "}
          <Link href="/sad-quotes" className="font-bold text-[#483aca]">
            sad quotes
          </Link>
          , are here not to dwell in sadness but to remind you that even in the
          darkest hours, there's a flicker of hope and the promise of a brighter
          tomorrow.
        </p>

        <h2 className="mb-2 text-lg font-semibold text-gray-900 uppercase">
          Funny Quotes - Laughter is the Best Medicine!
        </h2>
        <p className="text-[#3c4858] mb-3 font-normal text-sm">
          Life's too short not to laugh! Our{" "}
          <Link href="/funny-quotes" className="font-bold text-[#483aca]">
            Funny quotes
          </Link>
          ,are here to add a dash of humor to your day, proving that a good
          laugh can turn any ordinary moment into an extraordinary one. Because
          at Dream Bigly, we take our dreams seriously, but ourselves? Not so
          much!
        </p>

        <p className="text-[#3c4858] mb-3 font-normal text-sm">
          Dream Bigly is more than just a website; it's your daily companion on
          the journey to success, happiness, and a life filled with big dreams.
          Join us, laugh with us, dream with us, and let's make every moment
          count!
        </p>
        <p className="text-[#3c4858] mb-3 font-normal text-sm">
          [Follow us on social media for your daily dose of inspiration and
          laughter!]
        </p>
        
      </div>
    </div>
  );
};

export default AbousUs;
