/** @type {import('next').NextConfig} */

module.exports = {
  images: {
    domains: [
      "tailwindui.com",
      "img.dreambigly.in",
      "encrypted-tbn0.gstatic.com",
      "images.pexels.com",
      "images.unsplash.com",
    ], // Add all the domains of the image sources here
  },
  async rewrites() {
    return [
      {
        source: '/sitemap.xml',
        destination: '/api/sitemap',
      },
      // Add custom rewrites for page-specific robots.txt
      {
        source: '/robots.txt',
        destination: '/api/robots',
      },
    ];
  },
  reactStrictMode: true,
};
