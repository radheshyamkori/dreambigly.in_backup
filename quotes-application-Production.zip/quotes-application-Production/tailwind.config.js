/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx,svg}",
    "./pages/**/*.{js,ts,jsx,tsx,mdx,svg}",
    "./components/**/*.{js,ts,jsx,tsx,mdx,svg}",

    // Or if using `src` directory:
    "./src/**/*.{js,ts,jsx,tsx,mdx,svg}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

